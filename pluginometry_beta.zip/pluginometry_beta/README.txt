A Pen created at CodePen.io. You can find this one at http://codepen.io/codyhouse/pen/pIrbg.

 Just a handy login-signup modal window

Article and download on Cody:
http://codyhouse.co/gem/loginsignup-modal-window/